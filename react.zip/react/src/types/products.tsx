export interface IProduct {
  id: number;
  name: string;
  image: string;
  price: number;
  desc: string;
}
