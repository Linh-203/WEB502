import React, { useEffect, useState } from 'react';
import { Space, Table, Image, Button } from 'antd';
import { Link } from 'react-router-dom';
import type { ColumnsType } from 'antd/es/table';
// import { IProduct } from '../../types/products';

// interface IPrors {
//   products: IProduct[];
//   deletePro: (id: number) => void;
// }

const CategoryManagementPage = (prors) => {
  const [data, setData] = useState();

  useEffect(() => {
    setData(
      prors.category.map((cate) => {
        return { ...cate, key: cate.id };
      })
    );
  }, [prors]);
  console.log(prors.category);

  const deleteCate = (id) => {
    // const confirm = window.confirm('Ban co chac khong !');
    // if (confirm) {
    //
    // }
    prors.onRemoveCate(id);
  };
  // console.log(prors.products);
  // console.log(data.name);

  interface DataType {
    key: string;
    id: number;
    name: string;
    image: string;
    price: number;
    desc: string;
    categoryId: string;
  }

  const columns: ColumnsType<DataType> = [
    {
      title: 'Cate Name',
      dataIndex: 'name',
      key: 'name',
      render: (text) => <a>{text}</a>,
    },
    {
      title: 'Action',
      key: 'action',
      render: (_, record) => (
        <Space size="middle">
          <Button type="primary" danger onClick={() => deleteCate(record._id)}>
            Delete
          </Button>
          <Button type="primary">
            <Link
              className="link-no-underline"
              to={'/admin/category/' + record._id + '/update'}
            >
              Update
            </Link>
          </Button>
        </Space>
      ),
    },
  ];

  return (
    <div>
      <Button type="primary">
        <Link className="link-no-underline" to={'/admin/category/add'}>
          Add Category
        </Link>
      </Button>
      <Table columns={columns} dataSource={data} />
    </div>
  );
};
export default CategoryManagementPage;
