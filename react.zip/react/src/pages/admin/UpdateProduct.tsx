import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Form, Input, Table, Button, Select } from 'antd';
import { getAllCate } from '../../api/category';

const { Option } = Select;

const layout = {
  labelCol: {
    span: 8,
  },
  wrapperCol: {
    span: 16,
  },
};
const tailLayout = {
  wrapperCol: {
    offset: 8,
    span: 16,
  },
};
const UpdateProductPage = (props) => {
  const { id } = useParams();
  const [category, setCate] = useState([]);
  useEffect(() => {
    getAllCate().then(({ data }) => setCate(data));
  }, [props]);
  console.log(category);
  const [product, setProduct] = useState({});
  const navigate = useNavigate();
  useEffect(() => {
    const currentProduct = props.products.find((product) => product._id == id);
    setProduct(currentProduct);
  }, [props]);
  const onFinish = (values) => {
    const { name, price, desc, image, categoryId } = { ...product, ...values };
    props.onUpdate(id, { name, price, desc, image, categoryId }); //gọi hàm onUpdate từ props truyền vào
    //     navigate('/admin/products');
  };
  const onFinishFailed = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };
  return (
    <div>
      <Form
        {...layout}
        name="basic"
        initialValues={{
          remember: true,
        }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
      >
        <Form.Item
          label="Username"
          name="name"
          rules={[
            {
              required: true,
              message: 'Please input your username!',
            },
          ]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Price"
          name="price"
          rules={[
            {
              required: true,
              message: 'Please input your product price!',
            },
          ]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Image"
          name="image"
          rules={[
            {
              required: true,
              message: 'Please input your product product image!',
            },
          ]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Desc"
          name="desc"
          rules={[
            {
              required: true,
              message: 'Please input your product product desc!',
            },
          ]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          name="categoryId"
          label="category"
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Select
            placeholder="Select a option and change input text above"
            allowClear
          >
            {category.map((cate) => {
              return (
                <Option value={cate._id} key={cate._id}>
                  {cate.name}
                </Option>
              );
            })}
          </Select>
        </Form.Item>

        <Form.Item {...tailLayout}>
          <Button type="primary" htmlType="submit">
            Submit
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default UpdateProductPage;
