// import React, { useEffect } from 'react';
// import { useState } from 'react';

// const Login = ({ login, err }) => {
//   const [valueInput, setValueInput] = useState({});
//   console.log(err);
//   const onHandChange = (e) => {
//     const value = e.target.value;
//     const name = e.target.name;
//     setValueInput({ ...valueInput, [name]: value });
//   };
//   const onHandSubmit = (e) => {
//     e.preventDefault();
//     login(valueInput);
//   };
//   return (
//     <div className="containerLogin">
//       <div className="left">
//         <img
//           src="https://b-f8-zpc.zdn.vn/4319651230645055608/ee62705f615ebd00e44f.jpg"
//           alt=""
//         />
//       </div>
//       <div className="right">
//         <form onSubmit={onHandSubmit}>
//           <h1>Login</h1>
//           {/* <strong>{err}</strong> */}
//           <div className="form-group">
//             <label>Email</label>
//             <input
//               type="text"
//               name="email"
//               onChange={onHandChange}
//               className="form-control"
//               placeholder="Enter Price"
//             />
//           </div>
//           <div className="form-group">
//             <label>Password</label>
//             <input
//               type="password"
//               name="password"
//               onChange={onHandChange}
//               className="form-control"
//               placeholder="Enter Image"
//             />
//           </div>
//           <button type="submit" className="btn btn-primary btn-login">
//             Submit
//           </button>
//         </form>
//       </div>
//     </div>
//   );
// };

// export default Login;

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Form, Input, Button } from 'antd';

const layout = {
  labelCol: {
    span: 8,
  },
  wrapperCol: {
    span: 16,
  },
};
const tailLayout = {
  wrapperCol: {
    offset: 8,
    span: 16,
  },
};
const Login = ({ login, err }) => {
  const [errs, setErrs] = useState('');

  const navigate = useNavigate();
  const onFinish = async (values) => {
    await login(values);
    navigate('/admin/products');
  };
  const onFinishFailed = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };
  return (
    <div>
      <Form
        {...layout}
        name="basic"
        initialValues={{
          remember: true,
        }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
      >
        <Form.Item
          label="Email"
          name="email"
          rules={[
            {
              required: true,
              message: 'Please input your email',
            },
          ]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Password"
          name="password"
          rules={[
            {
              required: true,
              message: 'Please input your password!',
            },
          ]}
        >
          <Input />
        </Form.Item>

        <Form.Item {...tailLayout}>
          <Button type="primary" htmlType="submit">
            Submit
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default Login;
